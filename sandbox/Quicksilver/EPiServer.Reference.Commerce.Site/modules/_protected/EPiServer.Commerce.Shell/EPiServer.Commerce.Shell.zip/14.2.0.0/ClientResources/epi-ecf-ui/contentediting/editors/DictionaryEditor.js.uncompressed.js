﻿define("epi-ecf-ui/contentediting/editors/DictionaryEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/string",
    "dojo/when",
    // dojox
    "dojox/html/entities",
    // epi
    "epi/dependency",
    "epi/shell/command/_Command",
    "epi/shell/command/withConfirmation",
    "epi/shell/widget/dialog/Dialog",

    // epi-ecf-ui
    "./_GridWithAddCommand",
    "./DictionaryItemEditor",
    // resources
    "epi/i18n!epi/nls/commerce.widget.dictionaryadministration",
    "epi/i18n!epi/nls/episerver.shared"
], function(
    // dojo
    declare,
    lang,
    aspect,
    dojoString,
    when,
    // dojox
    htmlEntities,
    // epi
    dependency,
    _Command,
    withConfirmation,
    Dialog,
    // epi-ecf-ui
    _GridWithAddCommand,
    DictionaryItemEditor,
    // resources
    resources,
    sharedResources
) {
    return declare([_GridWithAddCommand], {

        storeKey: "epi.commerce.metadictionaryitem",

        dictionaryId: null,

        dialogType: Dialog,

        dialogContentType: DictionaryItemEditor,

        _confirmationHandler: null,

        resources: resources,

        // _noDataMessage: string
        //      String to notify that the grid content is empty.
        _noDataMessage: null,

        postCreate: function() {
            this._noDataMessage = this._noDataMessage || '<span><span class="dijitReset dijitInline">' + this.resources.nodatamessage + '</span></span>';
            this.inherited(arguments);
        },

        getAddCommand: function() {
            return new _Command({
                iconClass: "epi-iconPlus",
                canExecute: true,
                _execute: function() {
                    this._createAndShowDialog();
                }.bind(this)
            });
        },

        getDeleteCommand: function(object){
            // summary:
            //      Override to return correct delete command for rows in grid.
            // tags:
            //      protected

            var command = new _Command({
                iconClass: "epi-iconTrash",
                canExecute: true,
                _execute: function () {
                    return when(this.store.remove(object.id)).then(function () {
                         this.grid.refresh();
                    }.bind(this));
                }.bind(this)
            });
            // make sure the input object is un-touched by creating a cloned object, then modify the name property.
            var clonedObject = lang.clone(object);
            clonedObject.name = htmlEntities.encode(clonedObject.name);
            var dialogText = dojoString.substitute(this.resources.confirmationdescription, clonedObject);
            if (object.isInUse) {
                dialogText = dialogText + "<br /><br />" + this.resources.isinuse;
            }
            return withConfirmation(command, this._confirmationHandler, {
                title: this.resources.confirmationtitle,
                description: dialogText,
                confirmActionText: this.resources.confirmationtext,
                cancelActionText: sharedResources.action.cancel
            });
        },

        getColumnTitle: function() {
            return this.resources.values;
        },

        getItemId: function(item) {
            return item.id;
        },

        getGridQuery: function() {
            return {
                id: this.dictionaryId
            };
        },

        _createAndShowDialog: function() {
            if (this._dialog) {
                this._dialog.destroy();
                this._dialog = null;
            }
            var addValueContent = new this.dialogContentType({
                dictionaryId: this.dictionaryId
            });

            
            var grid = this.grid;
            this._dialog = new this.dialogType({
                dialogClass: "epi-dialog-confirm",
                defaultActionsVisible: true,
                confirmActionText: sharedResources.action.add,
                content: addValueContent,
                title: this.resources.addtitle,
                closeIconVisible: false,
                validate: function () {
                    return addValueContent.valueTextBox.validate();
                }
            });
            this._dialog.own(aspect.after(this._dialog, "onExecute", function() {
                when(addValueContent.saveToStore(), function() {
                    grid.refresh();
                });
            }));
            this.own(this._dialog);
            this._dialog.show();
        }
    });
});