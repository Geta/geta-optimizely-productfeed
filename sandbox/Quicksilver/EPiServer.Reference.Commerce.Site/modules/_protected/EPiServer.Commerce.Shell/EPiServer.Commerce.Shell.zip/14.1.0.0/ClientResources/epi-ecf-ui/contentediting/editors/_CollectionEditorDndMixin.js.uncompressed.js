﻿define("epi-ecf-ui/contentediting/editors/_CollectionEditorDndMixin", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/dom-construct",
    "dojo/dom-class",
    "dojo/aspect",

    "epi-cms/dgrid/DnD"
],
function (
    array,
    declare,
    domConstruct,
    domClass,
    aspect,

    DnD
) {
    return declare([], {

        _dndNodeCreator: function (/*Object*/item, /*Object*/hint) {
            // summary:
            //      Custom DnD avatar creator method
            //  tags:
            //      private

            var dndTypes = this.allowedDndTypes,
                node = domConstruct.create("div");

            return {
                "node": node,
                "type": dndTypes,
                "data": item
            };
        },

        _setupDnD: function () {
            // summary:
            //      Set up the dnd on the grid.
            // tags:
            //      private

            this.own(aspect.after(this.grid.dndSource, "onDropData", this.onDndDrop.bind(this), true));
        },

        onDndDrop: function (dndData, source, nodes, copy) {
            var i;

            // internal move
            if (this.grid.dndSource === source) {
                for (i = 0; i < nodes.length; i++) {
                    this.model.moveItem(
                        this.grid.dndSource.getItem(nodes[i].id).data,
                        this.grid.dndSource.current !== null ?
                            this.grid.dndSource.getItem(this.grid.dndSource.current.id).data :
                            null,
                        this.grid.dndSource.before
                    );
                }
                // external drop
            } else {
                // Set focus to mark start editing
                // make sure editor will be marked as start-editing immediately by invoking onDropping
                // to fix an issue in IE9, which was caused by the race condition,
                // which would lead to a problem of auto save.
                this.onDropping && this.onDropping();
                this.onFocus();

                for (i = 0; i < dndData.length; i++) {
                    this._addItem(dndData[i]);

                    // Remove from source?
                    // TODO: Simplify
                    if (source && source.grid && source.grid.consumer && source.grid.consumer !== this) {
                        source.grid.consumer.model.removeItem(this.grid.dndSource.getItem(nodes[i].id).data);
                    }
                }
            }
        }
    });
});