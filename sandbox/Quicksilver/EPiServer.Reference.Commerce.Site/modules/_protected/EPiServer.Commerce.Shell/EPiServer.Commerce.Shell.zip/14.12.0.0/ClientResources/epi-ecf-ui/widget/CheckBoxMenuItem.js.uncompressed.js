require({cache:{
'url:epi-ecf-ui/widget/templates/CheckBoxMenuItem.html':"<tr class=\"dijitReset dijitMenuItem epi-checkbox-menuitem\" data-dojo-attach-point=\"focusNode\" role=\"menuitemcheckbox\">\r\n\t<td class=\"epi-checkboxNode\">\r\n\t\t<input class=\"epi-checkbox-menuitem-input\" type=\"checkbox\" data-dojo-attach-point=\"checkbox\" \r\n\t\t\tdata-dojo-attach-event='onmousedown: _onMouseDown, onclick:_onCheckboxClick'/>\r\n\t\t<div class=\"indeterminate\" style=\"display: none;\"></div>\r\n    </td>\r\n\t<td class=\"dijitReset dijitMenuItemLabel dojoxEllipsis\" colspan=\"2\" data-dojo-attach-point=\"containerNode,labelNode\"></td>\r\n\t<td class=\"dijitReset dijitMenuItemAccelKey\" style=\"display: none\" data-dojo-attach-point=\"accelKeyNode\"></td>\r\n\t<td class=\"dijitReset dijitMenuArrowCell\" role=\"presentation\">&#160;</td>\r\n</tr>\r\n"}});
define("epi-ecf-ui/widget/CheckBoxMenuItem", [
    "dojo/_base/declare",
    "dojo/dom-prop",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/CheckedMenuItem",
    "dojo/text!./templates/CheckBoxMenuItem.html"
], function (declare, domProp, _TemplatedMixin, _WidgetsInTemplateMixin, CheckedMenuItem, template) {
    return declare([CheckedMenuItem, _TemplatedMixin, _WidgetsInTemplateMixin], {
        // summary:
        //		A checkbox-like menu item for toggling on and off
        // tags:
        //      internal xproduct

        // templateString: String
        //      The widget template string.
        templateString: template,

        _onMouseDown: function(evt) {
            evt.stopPropagation();
            evt.preventDefault();

            this.getParent().onItemClick(this, evt);
        },

        _onCheckboxClick: function(evt) {
            evt.stopPropagation();
            evt.preventDefault();
        },

        _setCheckedAttr: function (checked) {
            domProp.set(this.checkbox, "checked", checked);
            this._set("checked", checked);
        }
    });
});
