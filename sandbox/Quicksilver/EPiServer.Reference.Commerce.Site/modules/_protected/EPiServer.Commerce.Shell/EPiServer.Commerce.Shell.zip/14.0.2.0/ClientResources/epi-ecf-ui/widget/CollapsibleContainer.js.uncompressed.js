require({cache:{
'url:epi-ecf-ui/widget/templates/CollapsibleContainer.html':"﻿<div class=\"epi-collapsibleContainer\">\r\n    <div data-dojo-attach-point=\"titleBarNode\">\r\n        <div class=\"dijitInline\" data-dojo-attach-point=\"focusNode\">\r\n            <button data-dojo-type=\"dijit/form/ToggleButton\" data-dojo-attach-point=\"toggleButton\" data-dojo-attach-event=\"onClick:toggle\" \r\n                    data-dojo-props=\"showLabel:true, title:'${res.togglebuttontooltip}', iconClass:'epi-gadget-toggle', 'class':'epi-chromelessButton'\">${title}</button>\r\n        </div>\r\n        <div class=\"dijitInline epi-floatRight epi-visibleLink\" data-dojo-attach-point=\"headerNode\"></div>\r\n    </div>\r\n    <div data-dojo-attach-point=\"containerNode\"></div>\r\n    <div class=\"dijitHidden epi-collapsible__footer\" data-dojo-attach-point=\"footerNode\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/CollapsibleContainer", [
// dojo
    "dojo/_base/declare",

    "dojo/dom-class",
    "dojo/dom-construct",
// dijit
    "dijit/_Container",
    "dijit/_CssStateMixin",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",
    "dijit/_WidgetsInTemplateMixin",
// resources
    "epi/i18n!epi/shell/ui/nls/episerver.shell.ui.resources.gadgetchrome",
    "dojo/text!./templates/CollapsibleContainer.html",
// used in template
    "dijit/form/ToggleButton"
], function (
// dojo
    declare,

    domClass,
    domConstruct,
// dijit
    _Container,
    _CssStateMixin,
    _TemplatedMixin,
    _WidgetBase,
    _WidgetsInTemplateMixin,
// resources
    resources,
    template
) {

    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, _Container, _CssStateMixin], {
        // summary:
        //      Collapsible container with command.
        // tags:
        //      public

        res: resources,
        templateString: template,

        _setCollapsibleAttr: function (collapsible) {
            // summary:
            //      Sets collapsible for this container.
            // tags:
            //      protected

            this._set("collapsible", collapsible);

            !collapsible && this.toggleButton.set("iconClass", "");
        },

        _setOpenAttr: function (open) {
            // summary:
            //      Sets display for this container's content.
            // tags:
            //      protected

            this._set("open", open);

            this.containerNode && domClass.toggle(this.containerNode, "dijitHidden", !this.open);
            this.footerNode && domClass.toggle(this.footerNode, "dijitHidden", !this.open);
        },

        _setTitleAttr: function (title) {
            // summary:
            //      Sets text for this toggle heading.
            // tags:
            //      protected

            this._set("title", title);

            this.toggleButton && this.toggleButton.set("label", title);
        },

        addButton: function (button, options) {
            // summary:
            //      Adds button to container's node.
            // button: [Object]
            //      An instance of "dijit/form/Button" class.
            // options: [Object]
            //      Extended parameters that used to add the given button.
            // tags:
            //      public

            if (!button || !button.domNode) {
                return;
            }

            var region = options && options.region,
                container = this.containerNode;
            if (region) {
                switch (region) {
                    case "header":
                        container = this.headerNode;
                        break;
                    case "footer":
                        container = this.footerNode;
                        break;
                }
            }

            domClass.remove(container, "dijitHidden");
            domConstruct.place(button.domNode, container);
        },

        toggle: function () {
            // summary:
            //      Toggle display for this container's content.
            // tags:
            //      public

            this.get("collapsible") && this.set("open", !this.toggleButton.get("checked"));
        }

    });

});