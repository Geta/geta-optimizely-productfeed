﻿define("epi-ecf-ui/contentediting/editors/RelationGroupDefinitionEditor", [
    // dojo
    "dojo/_base/declare",
    // epi-ecf-ui
    "./_GridWithAddCommand",
    "./AddRelationGroupDefinitionCommand",
    // resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.relationgroupeditor"
], function(
    // dojo
    declare,
    // epi-ecf-ui
    _GridWithAddCommand,
    AddRelationGroupDefinitionCommand,
    // resources
    resources
){
    return declare([_GridWithAddCommand], {

        storeKey: "epi.commerce.relationgroupdefinition",

        getAddCommand: function() {
            return new AddRelationGroupDefinitionCommand();
        },

        getColumnTitle: function(){
            return resources.groupname;
        },

        getItemId: function(item){
            return item.name;
        }
    });
});