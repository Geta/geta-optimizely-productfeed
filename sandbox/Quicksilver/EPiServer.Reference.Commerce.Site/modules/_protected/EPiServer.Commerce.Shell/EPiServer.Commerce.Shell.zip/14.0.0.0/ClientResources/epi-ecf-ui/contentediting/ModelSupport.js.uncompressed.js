﻿define("epi-ecf-ui/contentediting/ModelSupport", [
],

function (
) {
    var modelSupport = {
        // summary:
        //    This class helps dealing with models
        //      * contains enums and constants
        // tags:
        //    public static
        
        // relationType: Object
        //      Types used on catalog relation models
        relationType: {
            undefined: 0,
            node: 1,
            bundleEntry: 2,
            packageEntry: 3,
            productVariation: 4
        },

        // relationRequestMode: Object
        //      Method of retrieving relations
        relationRequestMode: {
            bySource: 0,
            byTarget: 1
        },

        // contentTypeIdentifier: Object
        //      Type identifiers for catalog content types
        contentTypeIdentifier: {
            bundleContent: "episerver.commerce.catalog.contenttypes.bundlecontent",
            catalogContent: "episerver.commerce.catalog.contenttypes.catalogcontent",
            catalogContentBase: "episerver.commerce.catalog.contenttypes.catalogcontentbase",
            entryContentBase: "episerver.commerce.catalog.contenttypes.entrycontentbase",
            nodeContent: "episerver.commerce.catalog.contenttypes.nodecontent",
            nodeContentBase: "episerver.commerce.catalog.contenttypes.nodecontentbase",
            packageContent: "episerver.commerce.catalog.contenttypes.packagecontent",
            productContent: "episerver.commerce.catalog.contenttypes.productcontent",
            rootContent: "episerver.commerce.catalog.contenttypes.rootcontent",
            salesCampaign: "episerver.commerce.marketing.salescampaign",
            promotionData: "episerver.commerce.marketing.promotiondata",
            variationContent: "episerver.commerce.catalog.contenttypes.variationcontent"
        },
        
        // linkTypeIdentifier: Object
        //      Type identifiers for catalog link types
        linkTypeIdentifier: {
            association: "episerver.commerce.catalog.linking.association",
            relation: "episerver.commerce.catalog.linking.relation"
        }
    };

    return modelSupport;
});